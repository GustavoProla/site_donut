import styled from "styled-components"
// feito por joao trein
export const SectionCard = styled.section`
    display: flex;
    flex-wrap: wrap;
    align-items : center;
    gap: 8vw;
    margin-top: 5vh;
`
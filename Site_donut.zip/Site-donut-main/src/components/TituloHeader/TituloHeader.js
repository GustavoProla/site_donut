import { DetalhesTitulo } from "./TituloHeader.jsx"
import { TituloHeaderContainer } from "./TituloHeader.jsx"

function TituloHeader (){
return(
    <>
        <TituloHeaderContainer> Some sweets of
            <DetalhesTitulo> Hapiness</DetalhesTitulo>
        </TituloHeaderContainer>
    
    </>
)

}

export default TituloHeader
// import { AiOutlineSearch } from "react-icons/ai";
// import { RxHamburgerMenu } from "react-icons/rx";
// import { Cabecalho, Botao } from "./Header.jsx"
// function Header() {

//   // const icons = {
//   //     fontSize: '30px',
//   //     color: 'red',
//   //     display: 'flex',

//   //   };

//   return (
//     <>

//       <Cabecalho>
//           <Botao>
//               <RxHamburgerMenu />
//           </Botao>

//           <Botao>
//               <AiOutlineSearch />
//           </Botao>
//       </Cabecalho>


//     </>
//   );
// }

// export default Header
